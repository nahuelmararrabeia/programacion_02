﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace TestDataBase
{
    class Program
    {
        static void Main(string[] args)
        {
            //Persona.Borrar(new Persona("pepe","martinez", 15, 6));
            Persona persona = new Persona("pepe", "martinez", 15);
            //persona.Agregar();
            Persona.TraerTodosTabla();
            bool test = persona.Modificar();
            
            foreach (Persona i in Persona.TraerTodos())
            {
                Console.WriteLine(i.ToString());                
            }
            Console.WriteLine(Persona.TraerTodos(1));
            Console.WriteLine(test);
            Console.Read();
        }
    }
}
