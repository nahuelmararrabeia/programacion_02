﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public class Persona
    {
        private string _nombre;
        private string _apellido;
        private int _edad;
        private int _id;
        public string Nombre
        {
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        public string Apellido
        {
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        public int Edad
        {
            get { return this._edad; }
            set { this._edad = value; }
        }
        public int Id { get { return this._id; } }

        public Persona(string nombre, string apellido, int edad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Edad = edad;
        }
        public Persona(string nombre, string apellido, int edad, int id)
            : this(nombre, apellido, edad)
        {
            this._id = id;
        }

        public override string ToString()
        {
            string cadena = this._id + " - " + this._nombre +" - "+ this._apellido +" - "+ this._edad;
            return cadena;
        }

        public static List<Persona> TraerTodos()
        {
            List<Persona> lista = null;
            try
            {
                SqlConnection sqlPadron = new SqlConnection(Properties.Settings.Default.Conexion);
                sqlPadron.Open();
                SqlCommand comando = new SqlCommand("select id, nombre, apellido, edad from personas", sqlPadron);

                SqlDataReader reader = comando.ExecuteReader();
                lista = new List<Persona>();

                while (reader.Read())
                {
                    //reader["nombre"] 
                    lista.Add(new Persona(reader[1].ToString(), reader[2].ToString(), (int)reader[3], (int)reader[0]));
                }
                reader.Close();
                sqlPadron.Close();
            }
            catch {
                Console.WriteLine("error");
                return null;
            }
            return lista;
        }

        public bool Agregar()
        {
            try
            {
                SqlConnection conect = new SqlConnection(Properties.Settings.Default.Conexion);
                conect.Open();
                SqlCommand comando = new SqlCommand("insert into personas (nombre, apellido, edad) values ('"+this._nombre+"', '"+this._apellido+"'," + this._edad+")", conect);
                int consulta = comando.ExecuteNonQuery();
                conect.Close();
            }
            catch { return false; }
            return true;
        }

        public static bool Borrar(Persona p)
        {
            try
            {
                SqlConnection sqlPadron = new SqlConnection(Properties.Settings.Default.Conexion);
                sqlPadron.Open();
                SqlCommand comando = new SqlCommand("delete from personas where id =" + p.Id, sqlPadron);                
                int consulta = comando.ExecuteNonQuery();
            }catch{return false;}
            return true;
        }

        public bool Modificar()
        {
            try {
                SqlConnection sqlPadron = new SqlConnection(Properties.Settings.Default.Conexion);
                sqlPadron.Open();
                SqlCommand comando = new SqlCommand("update personas set nombre = '"+this._nombre+"', apellido='"+this._apellido+"', edad ="+this._edad+" where id=1" ,sqlPadron);
                sqlPadron.Close();
            }
            catch { return false; }
            return true;
        }
        public static Persona TraerTodos(int idParam)
        {
            Persona p = null;
            try
            {
                SqlConnection sql = new SqlConnection(Properties.Settings.Default.Conexion);
                sql.Open();
                SqlCommand comando = new SqlCommand("select * from personas where id =" + idParam, sql);
                SqlDataReader reader = comando.ExecuteReader();
                reader.Read();
                p = new Persona(reader[1].ToString(), reader[2].ToString(), (int)reader[3], (int)reader[0]);
                sql.Close();
                reader.Close();
            }
            catch { return p; }
            return p;
        }

        public static DataTable  TraerTodosTabla()
        {
            DataTable dT = null;
            try
            {
                SqlConnection sql = new SqlConnection(Properties.Settings.Default.Conexion);
                sql.Open();
                SqlCommand comando = new SqlCommand("select id, nombre, apellido, edad from personas", sql);
                SqlDataReader reader = comando.ExecuteReader();
                dT = new DataTable("personas");
                dT.Load(reader);
                
                reader.Close();
                sql.Close();
            }
            catch { return dT; }
            return dT;
        }
        
    }
}
