﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Recibo r1 = new Recibo(23);
            Recibo r2 = new Recibo();
            Factura f1 = new Factura(99);
            Factura f2 = new Factura(98);
            Contabilidad<Factura, Recibo> c1 = new Contabilidad<Factura, Recibo>();

            c1 += r1;
            c1 += r2;
            c1 += f1;
            c1 += f2;
            Console.WriteLine(c1);
            Console.ReadLine();
        }
    }
}
