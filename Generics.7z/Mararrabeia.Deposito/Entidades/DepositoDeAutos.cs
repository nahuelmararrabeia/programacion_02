﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;
        private DepositoDeAutos()
        { this._lista = new List<Auto>(); }
        public DepositoDeAutos(int capacidad):this()
        { this._capacidadMaxima = capacidad; }

        public static bool operator +(DepositoDeAutos d, Auto a)
        {
            bool retorno = false;
            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(a);
                retorno = true; 
            }                
            return retorno;
        }

        private int GetIndice(Auto a)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (this._lista.ElementAt(i) == a)
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator -(DepositoDeAutos d, Auto a)
        {
            bool retorno = false;
            if (d.GetIndice(a) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(a));
                retorno = true;
            }
            return retorno;
        }

        public bool Agregar(Auto a)
        { return (this + a); }

        public bool Remover(Auto a)
        { return (this - a); }

        public override string ToString()
        {
            string cadena = "Capacidad: " + this._capacidadMaxima;
            foreach (Auto i in this._lista)
            { cadena += i.ToString() +  "\n"; }
            return cadena;
        }
    }
}
