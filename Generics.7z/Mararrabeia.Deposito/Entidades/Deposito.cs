﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Deposito<T>
    {
        private int _capacidadMaxima;
        private List<T> _lista;
        private Deposito()
        { this._lista = new List<T>(); }
        public Deposito(int capacidad):this()
        { this._capacidadMaxima = capacidad; }

        public static bool operator +(Deposito<T> d, T a)
        {
            bool retorno = false;
            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(a);
                retorno = true; 
            }                
            return retorno;
        }

        private int GetIndice(T a)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (this._lista.ElementAt(i).Equals(a))
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator -(Deposito<T> d, T a)
        {
            bool retorno = false;
            if (d.GetIndice(a) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(a));
                retorno = true;
            }
            return retorno;
        }

        public bool Agregar(T a)
        { return (this + a); }

        public bool Remover(T a)
        { return (this - a); }

        public override string ToString()
        {
            string cadena = "Capacidad: " + this._capacidadMaxima + "\n";
            foreach (T i in this._lista)
            { cadena += i.ToString() + "\n"; }
            return cadena;
        }        
    }
}
