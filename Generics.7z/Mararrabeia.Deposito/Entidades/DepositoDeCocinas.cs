﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;
        private DepositoDeCocinas()
        { this._lista = new List<Cocina>(); }
        public DepositoDeCocinas(int capacidad):this()
        { this._capacidadMaxima = capacidad; }

        public static bool operator +(DepositoDeCocinas d, Cocina a)
        {
            bool retorno = false;
            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(a);
                retorno = true; 
            }                
            return retorno;
        }

        private int GetIndice(Cocina a)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (this._lista.ElementAt(i) == a)
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator -(DepositoDeCocinas d, Cocina a)
        {
            bool retorno = false;
            if (d.GetIndice(a) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(a));
                retorno = true;
            }
            return retorno;
        }

        public bool Agregar(Cocina a)
        { return (this + a); }

        public bool Remover(Cocina a)
        { return (this - a); }

        public override string ToString()
        {
            string cadena = "Capacidad: " + this._capacidadMaxima;
            foreach (Cocina i in this._lista)
            { cadena += i.ToString() + "\n"; }
            return cadena;
        }
    }
}
