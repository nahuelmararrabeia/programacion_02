﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace TestDataBase
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (Persona i in Persona.TraerTodos())
            {
                Console.WriteLine(i.Nombre);                
            }
            Console.Read();
        }
    }
}
