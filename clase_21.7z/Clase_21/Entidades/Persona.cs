﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public class Persona
    {
        private string _nombre;
        private string _apellido;
        private int _edad;
        private int _id;
        public string Nombre
        {
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        public string Apellido
        {
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        public int Edad
        {
            get { return this._edad; }
            set { this._edad = value; }
        }
        public int Id { get { return this._id; } }

        public Persona(string nombre, string apellido, int edad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Edad = edad;
        }
        public Persona(string nombre, string apellido, int edad, int id)
            : this(nombre, apellido, edad)
        {
            this._id = id;
        }

        public static List<Persona> TraerTodos()
        {
            List<Persona> lista = null;
            try
            {
                SqlConnection sqlPadron = new SqlConnection(Properties.Settings.Default.Conexion);
                sqlPadron.Open();
                SqlCommand comando = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [padron].[dbo].[personas]", sqlPadron);

                SqlDataReader reader = comando.ExecuteReader();
                lista = new List<Persona>();

                while (reader.Read())
                {
                    //reader["nombre"] 
                    lista.Add(new Persona(reader[1].ToString(), reader[2].ToString(), (int)reader[3], (int)reader[0]));
                }
                reader.Close();
                sqlPadron.Close();
            }
            catch {
                Console.WriteLine("error");
                return null;
            }
            return lista;
        }
        
    }
}
