<?php
	class Usuario
	{
		public $nombre;
		public $clave;

		function __construct($name, $pass)
		{
			$this->nombre = $name;
			$this->clave = $pass;
		}

		function ToString(){
			$salida = "$this->nombre - $this->clave";
			return $salida;
		}

		function ToJson()
		{
			return json_encode($this);
		}

		
	}

?>

