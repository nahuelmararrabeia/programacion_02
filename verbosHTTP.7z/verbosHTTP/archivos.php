<?php 
	include "./clases/usuario.php";
	
	/*if(!is_dir("./datos"))
	{
		mkdir("./datos");
	}

	$archivo=  fopen("./datos/datos.json", "w");
	
	fwrite($archivo, "hola");*/

	$usuarios = array();

	$archivoDatos = fopen("./datos/datos.json", "r");
	
	
    while(!feof($archivoDatos)) {    	
        $linea = fgets($archivoDatos);
        split(pattern, string)
        var_dump($obj);
         
        $user = new Usuario($obj["nombre"],$obj["clave"]);
        array_push($usuarios, $user);
    }    

	$usuario = new Usuario($_POST["nombre"], $_POST["clave"]);


	$archivo = fopen("./datos/datos.json", "w");
	fwrite($archivo, $usuario->ToJson());

	
	


?>