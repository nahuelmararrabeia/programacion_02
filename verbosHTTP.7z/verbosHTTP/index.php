<?php
	echo "hola";
	var_dump($_GET);
	var_dump($_POST);
	var_dump($_REQUEST);
	setcookie("kuki");
	var_dump($_COOKIE);	
	session_start();
	var_dump($_SESSION);
	//var_dump($_GET[]);
?>