﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace EntidadesClase20
{
    public class XML<T>
    {
        public bool GuardarXML(string path, T t)
        {
            try
            {
                XmlTextWriter xmlW = new XmlTextWriter(path, Encoding.UTF8);
                XmlSerializer xmlS = new XmlSerializer(typeof(T));
                xmlS.Serialize(xmlW, t);
                xmlW.Close();
            }
            catch
            {
                Console.WriteLine("error al serializar");
                Console.Read();
                return false;
            }
            return true;
        }

        public bool LeerXML(string path, out T t)
        {
            bool retorno = false;
            
                XmlTextReader xmlR = new XmlTextReader(path);
                XmlSerializer xmlS = new XmlSerializer(typeof(T));
                
                t = (T)xmlS.Deserialize(xmlR);
                Console.WriteLine(t.ToString());
                if(t!=null)
                retorno = true;          
            
            return retorno;
        }
    }

    

    
}
