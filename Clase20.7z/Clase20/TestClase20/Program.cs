﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase20;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace TestClase20
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\personas.xml";
            Alumno a1 = new Alumno("jorge", "perez", 400, 654);
            Alumno a2 = new Alumno("elena", "gonzalez", 333, 569);
            Profesor p1 = new Profesor("esteban", "gimenez", 897, "profesor");
            Aula aula = new Aula(2);
            
            
            
            Alumno aP = new Alumno();
            XML<Alumno> xmlA = new XML<Alumno>();
            //xmlA.GuardarXML(path,a1);
            xmlA.LeerXML(path, out aP);
            Console.WriteLine(aP.ToString());
            Console.Read();
            
        }
        public static bool GuardarXML(string path, Alumno alumno)
        {
            try
            {
                XmlTextWriter xmlW = new XmlTextWriter(path, Encoding.UTF8);
                XmlSerializer xmlS = new XmlSerializer(typeof(Alumno));
                xmlS.Serialize(xmlW, alumno);
                xmlW.Close();
            }
            catch
            {
                Console.WriteLine("error al serializar");
                return false;
            }
            return true;
        }
        public static bool LeerXML(string path, out Alumno alumnoOut)
        {
            try
            {
                XmlTextReader xmlR = new XmlTextReader(path);
                XmlSerializer xmlS = new XmlSerializer(typeof(Alumno));
                alumnoOut = (Alumno)xmlS.Deserialize(xmlR);
            }
            catch {
                Console.WriteLine("no se pudo leer");
                alumnoOut = null;
                return false;
            }
            Console.WriteLine(alumnoOut.ToString());
            return true;

        }
    }
}
