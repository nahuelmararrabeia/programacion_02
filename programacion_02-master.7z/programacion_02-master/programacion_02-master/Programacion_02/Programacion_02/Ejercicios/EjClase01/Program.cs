﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjClase01
{
    class Program
    {
        static void Main(string[] args)
        {            
            
            EntidadSello.Sello.color = ConsoleColor.Yellow;
            EntidadSello.Sello.mensaje = "skljdaklsjd";
            EntidadSello.Sello.Imprimir();
            
            Console.ResetColor();
            EntidadSello.Sello.Borrar();
            Console.WriteLine("pulse una tecla para salir");
            Console.ReadLine();
            Console.ReadLine();            
        }
    }
}
