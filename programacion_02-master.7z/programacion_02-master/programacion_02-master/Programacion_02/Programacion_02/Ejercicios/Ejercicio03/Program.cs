﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, i;
            int flag = 0;
            Console.WriteLine("ingrese numero");
            num = int.Parse(Console.ReadLine());
            for (i = num; i > 0; i--)
            {
                for (int j = (i - 1); j > 1; j--)
                {
                    if (i % j == 0)
                    {
                        flag = 1; 
                    }
                    
                }
                if (flag == 0)
                {
                    Console.WriteLine(i);
                    Console.ReadLine();
                }
            }

        }
    }
}
