﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    class Punto
    {
        private int x;
        private int y;

        public int GetX()
        {
            return this.x;
        }


        public int GetY()
        {
            return this.y;
        }

        public Punto(int a1, int a2)
        {
            this.x = a1;
            this.y = a2;
        }

    }

    

}
