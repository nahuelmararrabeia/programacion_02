﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadClases
{
    public class Tempera
    {
        private ConsoleColor color;
        private string marca;
        private int cantidad;

        public Tempera(ConsoleColor a, string b, int c);

        public string Mostrar()
        {
            string cadena;
            cadena = "color: " + color +"\n" + "marca: " + marca + "\n" + "cantidad: " + cantidad;
            return cadena;
        }

        public static string Mostrar(Tempera a)
        {
            return a.Mostrar();
        }


        public static bool operator == (Tempera a, Tempera b)
        {
            bool retorno= false;            
            if (a.marca == b.marca && a.color == b.color)
            {
                retorno= true;
            }            

            return retorno;                
        }

        public static bool operator !=(Tempera a, Tempera b)
        {
            return !(a == b);
        }



        public static Tempera operator +(Tempera a, int b)
        {
            a.cantidad = a.cantidad + b;
            return a;
        }

        public static Tempera operator +(Tempera a, Tempera b)
        {
            if (a == b)
            {
                a.cantidad = a.cantidad + b.cantidad;
            }
            return a;
        }



        public static Tempera operator -(Tempera a, Tempera b)
        {
            if (a == b)
            {
                a.cantidad = a.cantidad - b.cantidad;
            }
            return a;
        }




        public static implicit operator int(Tempera a)
        {
                                                                   

        }
               

    }
}
