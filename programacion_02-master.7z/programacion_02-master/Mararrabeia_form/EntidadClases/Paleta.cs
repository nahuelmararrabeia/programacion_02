﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadClases
{
    class Paleta
    {
        private Tempera[] _colores;
        private int _cantidadMaximaColores;

        private Paleta():this(5)
        { }

        private Paleta(int a)
        {
            this._cantidadMaximaColores = a;
            _colores = new Tempera[a];
        }

        /* public static Paleta operator implicit(int a)
        {
            Paleta[] p = new Paleta[a];
            return p;
        } */

        public static explicit operator string(Paleta a)
        {
            return a.Mostrar();
        }

        private string Mostrar()
        {

            string cadena="";
            for(int i=0; i<this._cantidadMaximaColores; i++)
            {
                cadena += this._colores[i];      

            }
            return cadena;
        }



        public static bool operator ==(Paleta a, Tempera b)
        {
            bool retorno = false;
            int i;
            for (i = 0; i < a._cantidadMaximaColores; i++)
            {
                if (a._colores[i] == b)
                    retorno = true;
                break;                                
            }
            return retorno;
        }



        public static bool operator !=(Paleta a, Tempera b)
        {
            return !(a == b);

        }




        private int ObtenerIndice()
        {
            int retorno=-1;
            for (int i = 0; i < this._cantidadMaximaColores; i++)
            {
                if (this._colores[i] == null)
                    retorno = i;                
            }
            return retorno;
        }




        private int ObtenerIndice(Tempera a)
        {
            int retorno = -1;            
            for(int i =0; i<this._cantidadMaximaColores;i++)
            {
                if(this._colores[i] == a)
                {
                    retorno = i;                   
                }
            }            

            return retorno;            
        }






        public static Paleta operator + (Paleta a, Tempera b)
        {
            int flag=0;
            for (int i = 0; i < a._cantidadMaximaColores; i++)
            {
                if (a._colores[i] == b)
                {
                    a._colores[i] = a._colores[i]  + b;
                    flag=1;
                }
            }
            if(flag==0)
            {
                
                if(a.ObtenerIndice() != -1)
                {
                    a._colores[a.ObtenerIndice()]= b;
                }
                
            }
            return a;

         }




        public static Paleta operator -(Paleta a, Tempera b)
        {
            int indice=a.ObtenerIndice(b);
            if(indice != -1)
            {
                if((a._colores[indice]-b) <1)
                {
                    a._colores[indice] = null ;
                }else{
                    a._colores[indice] = a._colores[indice] - b;
                }
            }
            return a;
        }


        }
    }
}
