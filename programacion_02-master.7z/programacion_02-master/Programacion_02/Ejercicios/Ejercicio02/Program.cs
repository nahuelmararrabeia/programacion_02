﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            float num;
            Console.WriteLine("ingresar numero");
            num= float.Parse (Console.ReadLine());

            if(num<0)
            {
                Console.WriteLine("ERROR. ¡Reingresar número!");
                num= float.Parse (Console.ReadLine());
            }
            double cuadrado = Math.Pow(num,2);
            double cubo = Math.Pow(num,3);
            Console.WriteLine("cuadrado: {0:#,###.00} cubo:{1:#,###.00}", cuadrado, cubo);
            Console.ReadLine();

        }
    }
}
