﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;            
            float max=0, min=0;
            float sumador = 0;
            float promedio;
            
            for (a = 0; a < 5; a++)
            {
                Console.WriteLine("ingrese numero:");
                float numero = float.Parse(Console.ReadLine());
                if (a == 0)
                {
                    max = numero;
                    min = numero;
                }
                else {
                    if (numero < min) 
                    {
                        min = numero;
                    }
                    if (numero > max)
                        max = numero; 
                }
                sumador = sumador + numero;
            }
            promedio = sumador / 5;
            Console.WriteLine("minimo:{0} maximo:{1} promedio:{2:#,###.00}", min ,max, promedio);
            Console.ReadLine();
        }
    }
}
