﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadSello
{

    public class Sello
    {
            public static ConsoleColor color;
            public static string mensaje;
            public static string mensajeRecuadro;
            public static bool vacio;

            public static void Imprimir() //escribe mensaje en consola 
            {
                Console.ForegroundColor = Sello.color;
                vacio = TryParse(mensaje, out mensaje);
                if (!vacio)
                {
                    mensaje = ArmarFormatoMensaje();
                    Console.WriteLine(Sello.mensaje);
                    Console.ReadLine();
                }
                else {
                    Console.WriteLine("no hay mensaje");
                    Console.ReadLine();                
                }

                


                
                
                
            }




            public static void Borrar() //bora la consola
            {
                Console.Clear();
                Console.Read();
            }




            private static string ArmarFormatoMensaje()
            {

                int cantLetras, i;
                string retorno="";
                cantLetras = Sello.mensaje.Length;
                for (i = 0; i < (cantLetras + 2); i++)
                {
                    retorno += "*";                                                                                
                }
                retorno+= "\n*";
                retorno += mensaje;
                retorno += "*\n";
                for (i = 0; i < (cantLetras + 2); i++)
                {
                    retorno += "*";
                }
                return retorno;                                     
            }




        private static bool TryParse(string mensaje, out string mensajeRecuadro)
        {
            bool confirma;
            if (mensaje == "")
            {
                confirma = true;
            }
            else {
                confirma = false;
            }
            mensajeRecuadro = mensaje;
            return confirma;
            
        }        
    }
    
}
