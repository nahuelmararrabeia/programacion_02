﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjClase01
{
    class Sello
    {
        public static string mensaje;

        public static void Imprimir() //escribe mensaje en consola 
            {
                Console.WriteLine(Sello.mensaje);
                Console.ReadLine();
            }


        public void Borrar() //bora la consola
            {
                Console.Clear();
            }
    }
}
