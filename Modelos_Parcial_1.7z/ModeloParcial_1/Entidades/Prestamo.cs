﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PrestamosPersonales
    {
        public abstract class Prestamo
        {
            protected float monto;
            protected DateTime vencimiento;
            public float Monto { get { return this.monto; } }
            public abstract float Interes { get; }
            public DateTime Vencimiento
            {
                get { return this.vencimiento; }

                set
                {
                    if (value.CompareTo(DateTime.Today) > 1)
                        this.vencimiento = value;
                    else
                        this.vencimiento = DateTime.Today;
                }
            }

            public Prestamo(float monto1, DateTime vencimiento1)
            {
                this.Vencimiento = vencimiento1;
                this.monto = monto1;
            }

            public static int OrdenarPorFecha(Prestamo p1, Prestamo p2)
            {
                int retorno = 0;
                if (p1.vencimiento > p2.vencimiento)
                    retorno = 1;
                if (p1.vencimiento < p2.vencimiento)
                    retorno = -1;

                return retorno;
            }

            public abstract void ExtenderPlazo(DateTime nuevoVencimiento);


            public virtual string Mostrar()
            {
                StringBuilder stringbuilder = new StringBuilder();
                stringbuilder.Append("Monto: " + this.monto);
                stringbuilder.Append("--Vencimiento: " + this.vencimiento.ToShortDateString());
                return stringbuilder.ToString();
            }
        }

        public enum TipoDePrestamo { Pesos, Dolares, Todos }
        public enum PeriodicidadDePagos { Mensual, Bimestral, Trimestral }

        public class PrestamoDolar : Prestamo
        {
            private PeriodicidadDePagos periodicidad;
            public override float Interes { get { return this.CalcularInteres(); } }
            public PeriodicidadDePagos Periodicidad { get { return this.periodicidad; } }

            private float CalcularInteres()
            {
                float retorno = 0;
                switch (this.periodicidad)
                {
                    case PeriodicidadDePagos.Mensual:
                        retorno = base.monto * 1.25f;
                        break;
                    case PeriodicidadDePagos.Bimestral:
                        retorno = base.monto * 1.35f;
                        break;
                    case PeriodicidadDePagos.Trimestral:
                        retorno = base.monto * 1.4f;
                        break;
                    default:
                        break;
                }
                return retorno;
            }

            public override void ExtenderPlazo(DateTime nuevoVencimiento)
            {
                for (DateTime i = base.vencimiento; i < nuevoVencimiento; i.AddDays(1))
                    this.monto += 2.5f;
                base.Vencimiento = nuevoVencimiento;
            }

            public override string Mostrar()
            {
                StringBuilder stringbuilder = new StringBuilder();
                stringbuilder.Append(base.Mostrar());
                stringbuilder.Append("-- " + this.periodicidad);
                stringbuilder.Append("--Interes: " + this.Interes);
                return stringbuilder.ToString();
            }

            public PrestamoDolar(float monto, DateTime vencimiento, PeriodicidadDePagos periodicidad):base(monto, vencimiento)
            {
                this.periodicidad = periodicidad;
            }

            public PrestamoDolar(Prestamo prestamo, PeriodicidadDePagos periodicidad)
                : this(prestamo.Monto, prestamo.Vencimiento, periodicidad)
            { }

        }

        public class PrestamoPesos : Prestamo
        {
            private float porcentajeInteres;
            public override float Interes { get { return this.CalcularInteres(); } }
            private float CalcularInteres()
            {
                float retorno = base.monto + (base.monto * this.porcentajeInteres) /100;
                return retorno;
            }

            public override void ExtenderPlazo(DateTime nuevoVencimiento)
            {
                for (DateTime i = base.vencimiento; i < nuevoVencimiento; i.AddDays(1))
                    this.porcentajeInteres += 0.25f;
                base.Vencimiento = nuevoVencimiento;
            }

            public override string Mostrar()
            {
                StringBuilder stringbuilder = new StringBuilder();
                stringbuilder.Append(base.Mostrar());
                stringbuilder.Append("--Porcentaje Interes: " + this.porcentajeInteres);
                stringbuilder.Append("% --Valor Interes: " + this.Interes);                
                return stringbuilder.ToString();
            }

            public PrestamoPesos(float monto, DateTime vencimiento, float interes)
                : base(monto, vencimiento)
            { this.porcentajeInteres = interes; }


            public PrestamoPesos(Prestamo prestamo, float porcentajeInteres)
                : this(prestamo.Monto, prestamo.Vencimiento, porcentajeInteres)
            { }
        }
    }
