﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PrestamosPersonales;

namespace Entidades
{
    public class Financiera
    {
        private List<Prestamo> listaDePrestamos;
        private string razonSocial;
        public List<Prestamo> ListaDePrestamos { get { return this.listaDePrestamos; } }
        public string RazonSocial { get { return this.razonSocial; } }
        public float InteresesEnDolares { get { return this.CalcularInteresGanado(TipoDePrestamo.Dolares); } }
        public float InteresesEnPesos { get { return this.CalcularInteresGanado(TipoDePrestamo.Pesos); } }
        public float InteresesTotales { get { return this.CalcularInteresGanado(TipoDePrestamo.Todos); } }

        private Financiera() { this.listaDePrestamos = new List<Prestamo>(); }
        public Financiera(string razon) : this() { this.razonSocial = razon; }

        public static string Mostrar(Financiera financiera)
        {
            return (string)financiera;             
        }
        public static explicit operator string(Financiera financiera)
        {
            StringBuilder stringbuilder = new StringBuilder();
            stringbuilder.AppendLine(financiera.razonSocial);
            stringbuilder.AppendLine("Intereses totales: "+financiera.InteresesTotales.ToString());
            stringbuilder.AppendLine("Intereses pesos: "+financiera.InteresesEnPesos.ToString());
            stringbuilder.AppendLine("Intereses Dolares: "+financiera.InteresesEnDolares.ToString());
            foreach(Prestamo i in financiera.listaDePrestamos)
                { stringbuilder.AppendLine(i.Mostrar()); }

            return stringbuilder.ToString();
        }

        public void OrdenarPrestamos() { this.listaDePrestamos.Sort(Prestamo.OrdenarPorFecha); }
        private float CalcularInteresGanado(TipoDePrestamo tipoPrestamo)
        {
            float contP=0, contD=0, retorno=0;
            foreach (Prestamo i in this.listaDePrestamos)
            {
                if (i is PrestamoDolar)
                    contD += i.Interes;
                if (i is PrestamoPesos)
                    contP += i.Interes;
            }
            switch (tipoPrestamo)
            {
                case TipoDePrestamo.Pesos:
                    retorno = contP;                    
                    break;
                case TipoDePrestamo.Dolares:
                    retorno = contD;
                    break;
                case TipoDePrestamo.Todos:
                    retorno = contD + contP;
                    break;
                default:
                    break;
            }
            return retorno;
        }

        public static Financiera operator +(Financiera financiera, Prestamo nuevoPrestamo)
        { 
            financiera.listaDePrestamos.Add(nuevoPrestamo);
            return financiera;
        }

        public static bool operator ==(Financiera financiera, Prestamo prestamo)
        {
            bool retorno = false;
            int flag=0;
            foreach (Prestamo i in financiera.listaDePrestamos)
            {
                if (i.Mostrar() == prestamo.Mostrar())
                    flag = 1;
            }
            if (flag == 1)
                retorno = true;

            return retorno;
        }

        public static bool operator !=(Financiera financiera, Prestamo prestamo)
        { return !(financiera == prestamo); }

    }
}
