﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ArticuloImportado : Articulo
    {
        private string _paisDeOrigen;
        private double _impuesto;
        public override float PrecioCosto
        {
            set
            {
                base.PrecioCosto = (value + (float)this._impuesto); // ver, no se modifica           
            }
        }

        public override string NombreYCodigo
        {
            get
            {
                return base.NombreYCodigo + "---" + this._paisDeOrigen;
            }
        }

        public ArticuloImportado(int codigo, string nombre, float precioCosto,int cantidad, string pais, double impuesto)
            :base(codigo,nombre,precioCosto,cantidad)
        {
            this._impuesto = impuesto;
            this._paisDeOrigen = pais;                        
        }


    }
}
