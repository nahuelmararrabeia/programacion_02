﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Articulo
    {
        private int _codigo;
        private string _nombre;
        private float _precioCosto;
        private float _precioVenta;
        private int _stock;

        public virtual string NombreYCodigo
        {
            get {
                string cadena= this._codigo+ "---"+this._nombre;
                return cadena;
            }
        }

        
        public virtual float PrecioCosto
        { set 
            { 
              this._precioCosto = value;
              this._precioVenta = (float)(this._precioCosto * 1.3); 
            } 
        }

        public float PrecioVenta
        { get { return this._precioVenta; } }

        public int Stock
        { set { this._stock = value; } }


        public Articulo(int codigo, string nombre, float precioCosto, int cantidad)
        {
            this._codigo = codigo;
            this._nombre = nombre;
            this.PrecioCosto = precioCosto;
            this.Stock = cantidad;
        }



        public bool HayStock(int cantidad)
        {
            bool retorno = false;
            if (this._stock > cantidad || cantidad == this._stock)
                retorno = true;

            return retorno;
        }

        public static bool operator ==(Articulo articuloUno, Articulo articuloDos)
        {
            bool retorno = false;
            if (articuloUno._nombre == articuloDos._nombre && articuloUno._codigo == articuloDos._codigo)
                retorno = true;

            return retorno;
        }

        public static bool operator !=(Articulo articuloUno, Articulo articuloDos)
        { return !(articuloUno == articuloDos); }



        public static int operator -(Articulo articuloUno, int cantidad)
        {
            int retorno = articuloUno._stock - cantidad;
            return retorno;
        }


        public static int operator +(Articulo articuloUno, Articulo articuloDos)
        {
            int retorno = articuloUno._stock + articuloDos._stock;
            return retorno;
        }


    }
}
