﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Comercio
    {
        private string _dueño;
        private List<Articulo> _misArticulos;
        private List<Venta> _misVentas;

        public Comercio(string dueño)
        { 
            this._dueño = dueño;
            this._misArticulos = new List<Articulo>();
            this._misVentas = new List<Venta>();
        }

        public void ComprarArticulo(Articulo articuloComprado)
        {
            int flag = 0;
            foreach (Articulo i in this._misArticulos)
            {
                if (i == articuloComprado)
                {
                    i.Stock = i + articuloComprado;
                    flag = 1;
                    break;
                }                   
            }
            if (flag == 0)
                this._misArticulos.Add(articuloComprado);
        }

        public static void MostrarArticulos(Comercio comercioAMostrar)
        {
            Console.WriteLine("Los productos existentes son\n");
            foreach (Articulo i in comercioAMostrar._misArticulos)
            { Console.WriteLine(i.NombreYCodigo); }
        }


        public static void MostrarGanancia(Comercio comercioParaResumen)
        {
            float ganancia=0;
            foreach (Venta i in comercioParaResumen._misVentas)
            {
                ganancia += i.RetornarGanancia();
            }
            Console.WriteLine("Ganancia: " + ganancia);
        }


        public void VenderArticulo(Articulo articuloSolicitado, int cantidad)
        {
            int flag = 0;
            foreach (Articulo i in this._misArticulos)
            {
                if (i == articuloSolicitado && i.HayStock(cantidad) == true)
                {
                    i.Stock = i - cantidad;
                    Venta nvaVenta = new Venta(articuloSolicitado, cantidad);
                    this._misVentas.Add(nvaVenta);
                }
                else if (i == articuloSolicitado && i.HayStock(cantidad) == false)
                    Console.WriteLine("El siguiente producto no tiene stock para la venta\n"+ i.NombreYCodigo);

                if (i == articuloSolicitado)
                    flag = 1;                
            }
            if (flag == 0)
                Console.WriteLine("El siguiente producto no existe en nuestro comercio\n" + articuloSolicitado.NombreYCodigo);
        }
    }
}
