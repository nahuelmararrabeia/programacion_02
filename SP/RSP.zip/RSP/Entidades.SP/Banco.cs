﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.SP
{
    public abstract class Banco
    {
        public string nombre;
        public Banco(string nombre)
        { this.nombre = nombre; }

        public abstract string Mostrar();
        public abstract string Mostrar(Banco b);
    }

    public class BancoNacional : Banco
    {
        public string pais;
        public BancoNacional(string nombre, string pais) : base(nombre)
        {
            this.pais = pais;            
        }
        
        public override string Mostrar()
            {
                return this.nombre;
            }

        public override string Mostrar(Banco b)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}-{1}", this.nombre, this.pais);
            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar(this);
        }
        
    }

    public class BancoProvincial : BancoNacional
    {
        public string provincia;
        public BancoProvincial(BancoNacional bn, string provincia) : base(bn.nombre, bn.pais)
        {
            this.provincia = provincia; 
        }

        public override string Mostrar()
        {
            return this.nombre;
        }

        public override string Mostrar(Banco b)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}-{1}-{2}", this.nombre, this.pais, this.provincia);
            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar(this);
        }
    }

    public class BancoMunicipal : BancoProvincial
    {
        public string municipio;
        public BancoMunicipal(BancoProvincial bp, string municipio) : base(new BancoNacional(bp.nombre, bp.pais), bp.provincia)
        {
            this.municipio = municipio;
        }

        public override string Mostrar()
        {
            return this.nombre;
        }

        public override string Mostrar(Banco b)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}-{1}-{2}-{3}", this.nombre, this.pais, this.provincia, this.municipio);
            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar(this);
        }
    }


}
