﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CentralitaHerencia;

namespace MiCentral
{
    class Program
    {
        static void Main(string[] args)
        {
            Centralita miCentral = new Centralita("Telefonica");
            Local llamada1 = new Local("bsas", 30, "cordoba", 2);
            Provincial llamada2 = new Provincial("cba", Franja.Franja_1, 21, "la pampa");
            Local llamada3 = new Local("tucuman", 45, "la rioja", 1);
            Provincial llamada4 = new Provincial("corrientes", Franja.Franja_3, 10, "mendoza");

            miCentral.Llamadas.Add(llamada1);
            miCentral.Llamadas.Add(llamada2);
            miCentral.Llamadas.Add(llamada3);
            miCentral.Llamadas.Add(llamada4);

            miCentral.Mostrar();            
        }
    }
}
