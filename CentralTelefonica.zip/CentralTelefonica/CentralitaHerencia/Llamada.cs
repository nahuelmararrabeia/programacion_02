﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Llamada
    {
        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;

        public float Duracion
        { get { return this._duracion; } }

        public string NroDestino
        { get { return this._nroDestino; } }

        public string NroOrigen
        { get { return this._nroOrigen; } }

        public Llamada(string origen, string destino, float duracion)
        {
            this._nroOrigen = origen;
            this._nroDestino = destino;
            this._duracion = duracion;
        }

        public virtual void Mostrar()
        {
            Console.WriteLine("Origen: {0}\nDestino: {1}\nDuracion: {2}", this.NroOrigen, this.NroDestino, this.Duracion);
            /*StringBuilder builder = new StringBuilder();
            Console.WriteLine(builder.Append(this._nroOrigen).Append("\n").Append(this._nroDestino).Append("\n").Append(this._duracion));*/
        }

        public static int OrdenarPorDuracion(Llamada uno, Llamada dos)
        {
            int retorno=0;
            if (uno._duracion > dos._duracion)
                retorno = 1;

            if (uno._duracion < dos._duracion)
                retorno = -1;

            return retorno;
        }
    }

    public class Local : Llamada
    {
        protected float _costo;

        public float CostoLlamada
        { get { return this._costo; } }

        private float CalcularCosto()
        {
            float retorno= base._duracion * this._costo;
            return retorno;            
        }

        public Local(Llamada unaLlamada, float costo) : base(unaLlamada.NroOrigen, unaLlamada.NroDestino,unaLlamada.Duracion)
        {
            this._costo = costo;
        }

        public Local(string origen, float duracion, string destino, float costo)
            : base(origen, destino, duracion)
        { this._costo = costo; }


        public override void Mostrar()
        {
 	         base.Mostrar();
             Console.WriteLine("Costo llamada: {0}\n", this.CostoLlamada);
        }
    }

    public enum Franja { Franja_1, Franja_2, Franja_3 };

    public class Provincial : Llamada
    {
        protected Franja _franjaHoraria;
        protected double _costo;

        public double Costo
        { get { return this._costo; } }

        public Provincial(Franja miFranja, Llamada unaLlamada)
            : base(unaLlamada.NroOrigen, unaLlamada.NroDestino, unaLlamada.Duracion)
        {
            switch (miFranja)
            {
                case Franja.Franja_1:
                    this._costo = 0.99;
                    break;
                case Franja.Franja_2:
                    this._costo = 1.25;
                    break;
                case Franja.Franja_3:
                    this._costo = 0.66;
                    break;
                default:
                    break;
            }
            this._franjaHoraria = miFranja;
        }


        public Provincial(string origen, Franja miFranja, float duracion, string destino)
            : base(origen, destino, duracion)
        {
            switch (miFranja)
            {
                case Franja.Franja_1:
                    this._costo = 0.99;
                    break;
                case Franja.Franja_2:
                    this._costo = 1.25;
                    break;
                case Franja.Franja_3:
                    this._costo = 0.66;
                    break;
                default:
                    break;
            }
            this._franjaHoraria = miFranja; 
        }




        private double CalcularCosto()
        {
            double retorno = this._costo * base._duracion;
            return retorno;
        }

        public override void Mostrar()
        {
            base.Mostrar();
            Console.WriteLine("Franja horaria: {0}\nCosto llamada: {1}\n", this._franjaHoraria, this._costo);
        }
    }

    public enum TipoLlamada { Local, Provincial, Todas };
}
