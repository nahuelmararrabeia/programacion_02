﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> _listaDeLlamadas;
        protected string _razonSocial;

        public static Centralita operator +(Centralita miCentral, Llamada nvaLlamada)
        {
            miCentral._listaDeLlamadas.Add(nvaLlamada);
            return miCentral;
        }

        public float GananciaPorLocal
        { get { return this.CalcularGanancia(TipoLlamada.Local); } }



        public float GananciaPorProvincial
        { get { return this.CalcularGanancia(TipoLlamada.Provincial); } }



        public float GananciaTotal
        { get { return this.CalcularGanancia(TipoLlamada.Todas); } }



        public List<Llamada> Llamadas
        { get { return this._listaDeLlamadas; } }



        public Centralita()
        { _listaDeLlamadas = new List<Llamada>();}



        public Centralita(string nombreEmpresa)
            : this()
        { this._razonSocial = nombreEmpresa; }




        private float CalcularGanancia(TipoLlamada tipo)
        {
            float contL = 0, contP = 0, retorno= 0;
            
            foreach (Llamada i in this._listaDeLlamadas)
            {
                if (i is Local)
                    contL += ((Local)i).CostoLlamada;

                if (i is Provincial)
                    contP += (float)((Provincial)i).Costo;
            }
            switch (tipo)
            {
                case TipoLlamada.Local:
                    retorno= contL;
                    break;
                case TipoLlamada.Provincial:
                    retorno = contP;
                    break;
                case TipoLlamada.Todas:
                    retorno = contP + contL;
                    break;
                default:
                    break;
            }
                return retorno;
        }


        public void Mostrar()
        {
            Console.WriteLine("Razon Social: {0}\nGanancia total:{1}\nGanancia locales: {2}\nGanancia provinciales: {3}\n\n", this._razonSocial, this.GananciaTotal, this.GananciaPorLocal, this.GananciaPorProvincial);
            foreach (Llamada i in this.Llamadas)
            {
                i.Mostrar();
            }
            Console.Read();
            
        }

    }
}
