﻿    public enum OrdenarLista
    {
        Nombre,
        Apellido,
        TipoUsuario
    }

    public enum CuadroDialogo
    {
        OpenFile,
        SaveFile
    }

    public enum TipoDeUsuario
    {
        Administrador,
        Invitado,
        Socio
    }