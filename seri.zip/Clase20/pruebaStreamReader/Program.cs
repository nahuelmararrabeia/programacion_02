﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using EntidadesClase20;
using System.Xml;
using System.Xml.Serialization;

namespace pruebaStreamReader
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\aula.xml";
            Aula al = new Aula();
            XmlTextReader reader = new XmlTextReader(path);
            XmlSerializer ser = new XmlSerializer(typeof(Aula));
            al =(Aula)ser.Deserialize(reader);
            Console.WriteLine(al);
            Console.Read();
            
        }
    }
}
