﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades
{
    public static class AdministradorDeArchivos
    {
        public static bool Escribir(string path, string texto, bool append)
        {
            bool retorno=true;
            try
            {
                StreamWriter archivo = new StreamWriter(path, append);
                archivo.WriteLine(texto);
                archivo.Close();
            }
            catch { retorno = false; }          
            return retorno;
        }
        public static bool Leer(string path, out string texto)
        {
            bool retorno = true;
            texto = "";
            try
            {
                StreamReader archivo = new StreamReader(path);
                texto = archivo.ReadToEnd();
                archivo.Close();
            }
            catch { retorno = false; }
            
            return retorno;
        }
    }
}
