﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    public enum EPuesto { Arquero, Defensa, Medio, Delantero }
    [Serializable]
    public class Jugador : ISerializableBinario, ISerializableXML
      
    {
        public string _nombre;
        public string _apellido;        
        public EPuesto _puesto;
        
        public string Nombre { get{return this._nombre;} }
        public string Apellido { get { return this._apellido; } }
        public EPuesto Puesto { get { return this._puesto; } }

        private Jugador() : this("", "", 0) { }
        public Jugador(string nombre, string apellido, EPuesto puesto)
        {
            this._apellido = apellido;
            this._nombre = nombre;
            this._puesto = puesto;
        }
        public override string ToString()
        {
            string cadena = this.Nombre + "-" + this.Apellido + "-" + this.Puesto;
            return cadena;
        }

        public static bool TraerUno(string path, Jugador jIn, out Jugador jOut)
        {
            string jugadores;
            string[] elementos;
            bool retorno= false;
            jOut = null;
            AdministradorDeArchivos.Leer(path, out jugadores);
            foreach(string i in jugadores.Split('\n'))
            {
                elementos = i.Split('-');
                if(jIn._nombre == elementos[0] && jIn._apellido == elementos[1] && jIn._puesto.ToString() == elementos[2].Trim())
                {
                    jOut = new Jugador(elementos[0], elementos[1], (EPuesto)Enum.Parse(typeof(EPuesto), elementos[2]));
                    retorno = true;
                }
            }
            return retorno;    
        }

        public void Serializar()
        {
            BinaryFormatter binF = new BinaryFormatter();
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\jugadores.dat";
            FileStream fileS = new FileStream(path, FileMode.Create);
            binF.Serialize(fileS, this);
            fileS.Close();
        }

        public Jugador Deserializar()
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\jugadores.dat";
            FileStream fileS = new FileStream(path, FileMode.Open);
            BinaryFormatter binF = new BinaryFormatter();
            Jugador j= (Jugador)binF.Deserialize(fileS);
            fileS.Close();
            return j;
        }
         void ISerializableXML.Serializar()
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\jugadores.xml";
            XmlTextWriter xmlW = new XmlTextWriter(path, Encoding.UTF8);
            XmlSerializer xmlS = new XmlSerializer(typeof(Jugador));
            xmlS.Serialize(xmlW, this);
            xmlW.Close();
        }

         Jugador ISerializableXML.Deserializar()
        {
            ///Jugador jugador = new Jugador();
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\jugadores.xml";
            XmlTextReader xmlR = new XmlTextReader(path);
            XmlSerializer xmlS = new XmlSerializer(typeof(Jugador));
            Jugador jugador = (Jugador)xmlS.Deserialize(xmlR);
            xmlR.Close();
            return jugador; 
        }

    }
}
