﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase20
{
    public abstract class Persona
    {
        protected string _nombre;
        protected string _apellido;
        protected int _dni;
        protected Persona(string nombre, string apellido, int dni)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._dni = dni;
        }
        public override string ToString()
        {
            string cadena = this._nombre + "-"+this._apellido +"-"+ this._dni;
            return cadena;
        }
    }

    public class Alumno : Persona
    {
        public int legajo;
        public Alumno(string nombre, string apellido, int dni, int legajo)
            : base(nombre, apellido, dni)
        { this.legajo = legajo; }

        public override string ToString()
        {
            string cadena = base.ToString() + "-" + this.legajo;
            return cadena;
        }
    }

    public class Profesor : Persona
    {
        public string titulo;
        public Profesor(string nombre, string apellido, int dni, string titulo)
            : base(nombre, apellido, dni)
        { this.titulo = titulo; }

        public override string ToString()
        {
            string cadena = base.ToString() + "-" + this.titulo;
            return cadena;
        }
    }
}
