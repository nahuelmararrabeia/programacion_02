﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormDatos
{
    public partial class frmDatosS : Form
    {
        public frmDatosS()
        {
            InitializeComponent();
        }
        public void ActualizarDatos(string a)
        {
            this.label1.Text = a;
        }


    }
}
