﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;


namespace test

{    
    public class Program
    {
        static void Main(string[] args)
        {            
            Empleado empleado = new Empleado("jorge", "perez", 4000000);
            empleado.SueldoCero += new DelSueldoCero(empleado.ManejadorEvento);
            empleado.SueldoMaximo += new DelLimiteSueldo(empleado.LimiteSueldo); 
            empleado.Sueldo = 0;           
            Console.Read();
        }
    }
}
