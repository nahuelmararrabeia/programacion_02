﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    public delegate void DelSueldoCero();
    public delegate void DelLimiteSueldo(double sueldo, Empleado empleado);
    
    public class Empleado
    {
        public string _nombre;
        public string _apellido;
        public int _dni;
        private double _sueldo;
        public double Sueldo
        {
            get { return this._sueldo; }
            set 
            {
                if (value == 0)
                    this.SueldoCero();
                if (value < 0)
                    { SueldoNegativoExeption ex = new SueldoNegativoExeption(); }
                else { this._sueldo = value; }
                
            }
        }
        public Empleado(string nombre, string apellido, int dni)
        {
            this._apellido = apellido;
            this._dni = dni;
            this._nombre = nombre;
        }
        public override string ToString()
        {
            string cadena = this._nombre + "-" + this._apellido + "-" + this._dni + "- $" + this._sueldo;
            return cadena;
        }
        public event DelSueldoCero SueldoCero;
        
        public void ManejadorEvento()
        {            
            if(this.Sueldo == 0)
                Console.WriteLine("el sueldo es = 0");            
        }

        public event DelLimiteSueldo SueldoMaximo;
        public void LimiteSueldo(double sueldo, Empleado empleado)
        {
            if (empleado.Sueldo > sueldo)
            { 
                Console.WriteLine("sueldo alto");
                this.SueldoMaximo(sueldo, empleado);
            }
                
        }


    }
}
