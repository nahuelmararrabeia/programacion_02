﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelLimiteSueldoMejorado(Empleado empleado, EmpleadoEventArgs args);
    public class EmpleadoEventArgs : EventArgs
    {
        public double Sueldo { get; set; }
        public event DelLimiteSueldoMejorado SueldoMaximoMejorado;

        public void SueldoMaximo(Empleado empleado, EmpleadoEventArgs evento)
        {
            if (this.Sueldo>20000 && this.Sueldo < 30000)
                this.SueldoMaximoMejorado(empleado, evento);

        }
    }
}
