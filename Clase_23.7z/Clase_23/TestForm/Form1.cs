﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace TestForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Empleado empleado = new Empleado(txtNombre.Text, txtApellido.Text, int.Parse(txtDNI.Text));
            empleado.SueldoCero += new DelSueldoCero(ManejadorEvento);
            empleado.Sueldo = double.Parse(txtSueldo.Text);
            
            void ManejadorEvento()
            {
                MessageBox.Show("el suedo es 0");
            }
        }
    }
}

