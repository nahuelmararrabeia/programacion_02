﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string numero = "";
        string operador = "";

        private void Form1_Load(object sender, EventArgs e)
        {
            this.btn1.Click += new EventHandler(ManejadorCentral);
            this.btn2.Click += new EventHandler(ManejadorCentral);
            this.btn3.Click += new EventHandler(ManejadorCentral);
            this.btn4.Click += new EventHandler(ManejadorCentral);
            this.btn5.Click += new EventHandler(ManejadorCentral);
            this.btn6.Click += new EventHandler(ManejadorCentral);
            this.btn7.Click += new EventHandler(ManejadorCentral);
            this.btn8.Click += new EventHandler(ManejadorCentral);
            this.btn9.Click += new EventHandler(ManejadorCentral);
        }
        private void ManejadorCentral(object sender, EventArgs e)
        {
            if ((Button)sender == btn1)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);   
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral); 
                if (operador != "")
                   this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 1;
            }

            if ((Button)sender == btn2)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 2;
            }

            if ((Button)sender == btn3)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 3;
            }

            if ((Button)sender == btn4)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 4;
            }

            if ((Button)sender == btn5)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 5;
            }

            if ((Button)sender == btn6)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 6;
            }

            if ((Button)sender == btn7)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 7;
            }

            if ((Button)sender == btn8)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 8;
            }

            if ((Button)sender == btn9)
            {
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
                this.btnDivision.Click += new EventHandler(ManejadorCentral);
                this.btnSuma.Click += new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click += new EventHandler(ManejadorCentral);
                this.btnResta.Click += new EventHandler(ManejadorCentral);
                if (operador != "")
                    this.btnCalcular.Click += new EventHandler(ManejadorCentral);
                txtDisplay.Text += 9;
            }
            if ((Button)sender == btnSuma)
            {
                numero = txtDisplay.Text;
                operador = "+";
                txtDisplay.Text = "";
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);             
            }
            if ((Button)sender == btnResta)
            {
                numero = txtDisplay.Text;
                operador = "-";
                txtDisplay.Text = "";
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
            }
            if ((Button)sender == btnDivision)
            {
                numero = txtDisplay.Text;
                operador = "/";
                txtDisplay.Text = "";
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
            }
            if ((Button)sender == btnMultiplicacion)
            {
                numero = txtDisplay.Text;
                operador = "*";
                txtDisplay.Text = "";
                this.btnDivision.Click -= new EventHandler(ManejadorCentral);
                this.btnSuma.Click -= new EventHandler(ManejadorCentral);
                this.btnMultiplicacion.Click -= new EventHandler(ManejadorCentral);
                this.btnResta.Click -= new EventHandler(ManejadorCentral);
            }
            if ((Button)sender == btnCalcular)
            {
                int numero1 = int.Parse(numero);
                int numero2 = int.Parse(txtDisplay.Text);
                if (operador == "+")
                    txtDisplay.Text = (numero1 + numero2).ToString();
                if (operador == "-")
                    txtDisplay.Text = (numero1 - numero2).ToString();
                if (operador == "/")
                    txtDisplay.Text = (numero1 / numero2).ToString();
                if (operador == "*")
                    txtDisplay.Text = (numero1 * numero2).ToString();
                numero = "";
                operador = "";
                this.btnCalcular.Click -= new EventHandler(ManejadorCentral);
                this.btnLimpiar.Click += new EventHandler(ManejadorCentral);
            }
            if ((Button)sender == btnLimpiar)
            {
                txtDisplay.Text = "";
                numero = "";
                operador = "";
                this.btnLimpiar.Click -= new EventHandler(ManejadorCentral);
            }                
        }
    }
}
