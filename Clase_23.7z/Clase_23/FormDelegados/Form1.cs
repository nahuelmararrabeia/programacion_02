﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using frmDatos;
using Entidades;
using FormDatos;

namespace FormDelegados
{
    public delegate void Nexofrm(string s);
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void testDelegadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTestDelegados frmPruebaDelegados = new frmTestDelegados();
            
            frmPruebaDelegados.Show(this); 
            
        }

        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDatosS frmDatos = new frmDatosS();
            frmDatos.Show(this);
        }
        public Nexofrm Nexo;
        public void NexoString()
        {
 
        }
    }
}
