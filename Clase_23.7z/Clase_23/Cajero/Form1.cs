﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cajero
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.btnAceptar.Click += new EventHandler(Calcular);
            this.btnSalir.Click += new EventHandler(Cerrar);
        }

        private void Calcular(object sender, EventArgs e)
        {
            int total = int.Parse(txtTotal.Text);
            int billetesCien=0, billetesCincuenta=0, billetesVeinte=0, billetesDiez=0;
            int billetesCinco=0,billetesDos=0;

            for (int i = 0; total > 0; i++)
            {
                if (total >= 100)
                {
                    billetesCien += 1;
                    total -= 100;
                } else if (total >= 50)
                {
                    billetesCincuenta += 1;
                    total -= 50;
                }else if (total >= 20)
                {
                    billetesVeinte += 1;
                    total -= 20;
                }else if (total >= 10)
                {
                    billetesDiez += 1;
                    total -= 10;
                }else if (total >= 5)
                {
                    billetesCinco += 1;
                    total -= 5;
                }
                else if (total >= 2)
                {
                    billetesDos += 1;
                    total -= 2;
                }else { 
                    MessageBox.Show("vuelto: $1");
                    total -= 1;
                }                
            }
            txt100pesos.Text = billetesCien.ToString();
            txt50pesos.Text = billetesCincuenta.ToString();
            txt20pesos.Text = billetesVeinte.ToString();
            txt10pesos.Text = billetesDiez.ToString();
            txt5pesos.Text = billetesCinco.ToString();
            txt2pesos.Text = billetesDos.ToString();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.btnAceptar.Click -= new EventHandler(Calcular);
            this.btnLimpiar.Click += new EventHandler(Limpiar);
            this.btnAceptar.Click += new EventHandler(Informar);

        }
        private void Limpiar(object sender, EventArgs e)
        {
            foreach (Control i in this.Controls)
            {
                if (i is TextBox)
                    i.Text = "";
            }
        }

        private void Informar(object sender, EventArgs e)
        { MessageBox.Show("Debe limpiar la pantalla para seguir operando"); }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            this.btnAceptar.Click -= new EventHandler(Informar);
            this.btnLimpiar.Click -= new EventHandler(Limpiar);
            this.btnAceptar.Click += new EventHandler(Calcular);
        }
        private void Cerrar(object sender, EventArgs e)
        { this.Close(); }

    }
}
