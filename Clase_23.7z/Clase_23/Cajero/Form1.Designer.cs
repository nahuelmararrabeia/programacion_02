﻿namespace Cajero
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txt2pesos = new System.Windows.Forms.TextBox();
            this.txt5pesos = new System.Windows.Forms.TextBox();
            this.txt10pesos = new System.Windows.Forms.TextBox();
            this.txt20pesos = new System.Windows.Forms.TextBox();
            this.txt50pesos = new System.Windows.Forms.TextBox();
            this.txt100pesos = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lbl2pesos = new System.Windows.Forms.Label();
            this.lbl5pesos = new System.Windows.Forms.Label();
            this.lbl10pesos = new System.Windows.Forms.Label();
            this.lbl20pesos = new System.Windows.Forms.Label();
            this.lbl50pesos = new System.Windows.Forms.Label();
            this.lbl100pesos = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtTotal.Location = new System.Drawing.Point(183, 38);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 0;
            // 
            // txt2pesos
            // 
            this.txt2pesos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt2pesos.Location = new System.Drawing.Point(183, 154);
            this.txt2pesos.Name = "txt2pesos";
            this.txt2pesos.ReadOnly = true;
            this.txt2pesos.Size = new System.Drawing.Size(100, 20);
            this.txt2pesos.TabIndex = 1;
            // 
            // txt5pesos
            // 
            this.txt5pesos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt5pesos.Location = new System.Drawing.Point(183, 189);
            this.txt5pesos.Name = "txt5pesos";
            this.txt5pesos.ReadOnly = true;
            this.txt5pesos.Size = new System.Drawing.Size(100, 20);
            this.txt5pesos.TabIndex = 2;
            // 
            // txt10pesos
            // 
            this.txt10pesos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt10pesos.Location = new System.Drawing.Point(183, 226);
            this.txt10pesos.Name = "txt10pesos";
            this.txt10pesos.ReadOnly = true;
            this.txt10pesos.Size = new System.Drawing.Size(100, 20);
            this.txt10pesos.TabIndex = 3;
            // 
            // txt20pesos
            // 
            this.txt20pesos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt20pesos.Location = new System.Drawing.Point(183, 262);
            this.txt20pesos.Name = "txt20pesos";
            this.txt20pesos.ReadOnly = true;
            this.txt20pesos.Size = new System.Drawing.Size(100, 20);
            this.txt20pesos.TabIndex = 4;
            // 
            // txt50pesos
            // 
            this.txt50pesos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt50pesos.Location = new System.Drawing.Point(183, 298);
            this.txt50pesos.Name = "txt50pesos";
            this.txt50pesos.ReadOnly = true;
            this.txt50pesos.Size = new System.Drawing.Size(100, 20);
            this.txt50pesos.TabIndex = 5;
            // 
            // txt100pesos
            // 
            this.txt100pesos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt100pesos.Location = new System.Drawing.Point(183, 334);
            this.txt100pesos.Name = "txt100pesos";
            this.txt100pesos.ReadOnly = true;
            this.txt100pesos.Size = new System.Drawing.Size(100, 20);
            this.txt100pesos.TabIndex = 6;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(80, 45);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(87, 13);
            this.lblTotal.TabIndex = 7;
            this.lblTotal.Text = "Cantidad a retirar";
            // 
            // lbl2pesos
            // 
            this.lbl2pesos.AutoSize = true;
            this.lbl2pesos.Location = new System.Drawing.Point(80, 161);
            this.lbl2pesos.Name = "lbl2pesos";
            this.lbl2pesos.Size = new System.Drawing.Size(64, 13);
            this.lbl2pesos.TabIndex = 8;
            this.lbl2pesos.Text = "Billetes de 2";
            // 
            // lbl5pesos
            // 
            this.lbl5pesos.AutoSize = true;
            this.lbl5pesos.Location = new System.Drawing.Point(80, 196);
            this.lbl5pesos.Name = "lbl5pesos";
            this.lbl5pesos.Size = new System.Drawing.Size(64, 13);
            this.lbl5pesos.TabIndex = 9;
            this.lbl5pesos.Text = "Billetes de 5";
            // 
            // lbl10pesos
            // 
            this.lbl10pesos.AutoSize = true;
            this.lbl10pesos.Location = new System.Drawing.Point(80, 233);
            this.lbl10pesos.Name = "lbl10pesos";
            this.lbl10pesos.Size = new System.Drawing.Size(70, 13);
            this.lbl10pesos.TabIndex = 10;
            this.lbl10pesos.Text = "Billetes de 10";
            // 
            // lbl20pesos
            // 
            this.lbl20pesos.AutoSize = true;
            this.lbl20pesos.Location = new System.Drawing.Point(80, 262);
            this.lbl20pesos.Name = "lbl20pesos";
            this.lbl20pesos.Size = new System.Drawing.Size(70, 13);
            this.lbl20pesos.TabIndex = 11;
            this.lbl20pesos.Text = "Billetes de 20";
            // 
            // lbl50pesos
            // 
            this.lbl50pesos.AutoSize = true;
            this.lbl50pesos.Location = new System.Drawing.Point(80, 305);
            this.lbl50pesos.Name = "lbl50pesos";
            this.lbl50pesos.Size = new System.Drawing.Size(70, 13);
            this.lbl50pesos.TabIndex = 12;
            this.lbl50pesos.Text = "Billetes de 50";
            // 
            // lbl100pesos
            // 
            this.lbl100pesos.AutoSize = true;
            this.lbl100pesos.Location = new System.Drawing.Point(80, 341);
            this.lbl100pesos.Name = "lbl100pesos";
            this.lbl100pesos.Size = new System.Drawing.Size(76, 13);
            this.lbl100pesos.TabIndex = 13;
            this.lbl100pesos.Text = "Billetes de 100";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(385, 213);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 14;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(385, 142);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.TabIndex = 15;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(385, 281);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 23);
            this.btnSalir.TabIndex = 16;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 423);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.lbl100pesos);
            this.Controls.Add(this.lbl50pesos);
            this.Controls.Add(this.lbl20pesos);
            this.Controls.Add(this.lbl10pesos);
            this.Controls.Add(this.lbl5pesos);
            this.Controls.Add(this.lbl2pesos);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.txt100pesos);
            this.Controls.Add(this.txt50pesos);
            this.Controls.Add(this.txt20pesos);
            this.Controls.Add(this.txt10pesos);
            this.Controls.Add(this.txt5pesos);
            this.Controls.Add(this.txt2pesos);
            this.Controls.Add(this.txtTotal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txt2pesos;
        private System.Windows.Forms.TextBox txt5pesos;
        private System.Windows.Forms.TextBox txt10pesos;
        private System.Windows.Forms.TextBox txt20pesos;
        private System.Windows.Forms.TextBox txt50pesos;
        private System.Windows.Forms.TextBox txt100pesos;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lbl2pesos;
        private System.Windows.Forms.Label lbl5pesos;
        private System.Windows.Forms.Label lbl10pesos;
        private System.Windows.Forms.Label lbl20pesos;
        private System.Windows.Forms.Label lbl50pesos;
        private System.Windows.Forms.Label lbl100pesos;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnSalir;
    }
}

