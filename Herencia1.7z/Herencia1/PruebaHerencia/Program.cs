﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Herencia1;

namespace PruebaHerencia
{
    class Program
    {
        static void Main(string[] args)
        {
            Lavadero miLavadero = new Lavadero(2000, 3000, 1000);

            Auto auto1 = new Auto("bbb123", 4 ,Vehiculo.EMarcas.Fiat, 4);
            Auto auto2 = new Auto("aaa123", 4 ,Vehiculo.EMarcas.Ford, 4);
            Camion camion1 = new Camion("ddd123", 4, Vehiculo.EMarcas.Iveco, 4);
            Camion camion2 = new Camion("ccc123", 4, Vehiculo.EMarcas.Scania, 4);
            Moto moto1 = new Moto("fff123", 2, Vehiculo.EMarcas.Zanella, 2);
            Moto moto2 = new Moto("eee123", 2, Vehiculo.EMarcas.Honda, 2);

            miLavadero += auto1;
            miLavadero += auto2;
            miLavadero += moto1;
            miLavadero += moto2;
            miLavadero += camion1;
            miLavadero += camion2;

            miLavadero._Vehiculos.Sort(Lavadero.OrdenarVehiculosPorPatente);

            Console.Write(miLavadero._Lavadero);
            Console.Write("\ntotal facturado: " +miLavadero.MostrarTotalFacturado());
            Console.Write("\ntotal facturado por camiones: " + miLavadero.MostrarTotalFacturado(Lavadero.EVehiculos.Camion));
            
            Console.ReadLine();
        }
    }
}
