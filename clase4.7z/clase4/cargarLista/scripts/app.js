var lista = [];
var txtNombre;
var txtEdad;

function Persona(nombre,edad){
    this.nombre = nombre;
    this.edad = edad;
}

window.addEventListener('load', asignarManejadores);
function asignarManejadores(){
    //var frm = document.forms[0];
    var frm = document.getElementById('frmAlta');
    frm.addEventListener('submit', manejarEnvio, false);
    txtNombre = document.getElementById('txtNombre');
    txtEdad = document.getElementById('txtEdad');
}

function manejarEnvio(e){
    //captura el evento submit por defecto
    e.preventDefault();
    cargarLista();
}

function cargarLista(){
    var nuevaPersona = new Persona(txtNombre.value, parseInt(txtEdad.value));
    lista.push(nuevaPersona);

    refrescarLista();
}

function refrescarLista(){
    var tabla = "<table id ='tablaPersonas'><tr><th>Nombre</th><th>Edad</th></tr>";
    for(let i = 0; i<lista.length;i++)
    {
         tabla += "<tr><td>"+lista[i].nombre+"</td><td>"+lista[i].edad+"</td>";
    }
    tabla += "</table>";
    document.getElementById("divTabla").innerHTML = tabla;
}