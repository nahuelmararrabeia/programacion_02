window.addEventListener('load', asignarManejadores);

function asignarManejadores(){
    document.getElementById("btnCrearP").addEventListener('click', crearParrafo);
    document.getElementById("btnCrearImg").addEventListener('click', crearImagen);
    document.getElementById("btnClearLast").addEventListener('click',borrarUltimo);
    document.getElementById("btnClearFirst").addEventListener('click',borrarPrimer);
    document.getElementById("btnSustituir").addEventListener('click',sustituir);
}

function crearParrafo(){
    var parrafo = document.createElement('p');
    var texto  = document.createTextNode(document.getElementById('txtArea').value);
    parrafo.appendChild(texto);    
    document.getElementById("div1").appendChild(parrafo);
}

function crearImagen(){
    var imagen = document.createElement('img');
    imagen.src = "./sandia.jpg";
    imagen.setAttribute('height','300px');
    document.getElementById("div1").appendChild(imagen);
        
}

function borrarUltimo(){
    var div = document.getElementById("div1");
    var hijo = div.lastChild;
    div.removeChild(hijo);
}

function borrarPrimer(){
    var div = document.getElementById("div1");
    var hijo = div.firstChild;
    div.removeChild(hijo);
}

function sustituir(){
    var parrafo = document.createElement('p');
    var texto  = document.createTextNode("hola mundo");   
    parrafo.appendChild(texto);
    document.getElementById("div1").replaceChild(parrafo,document.getElementById("div1").firstChild)
}