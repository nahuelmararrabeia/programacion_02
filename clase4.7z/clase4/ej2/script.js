window.addEventListener('load', asignarManejadores);

function asignarManejadores(){
    document.getElementById("btnCambioTexto").addEventListener('click', cambioTexto);
    document.getElementById("btnCambioClases").addEventListener('click', cambioClase);
    document.getElementById("btnSacoClases").addEventListener('click',sacoClases);
}

function cambioTexto(){
    document.getElementById("p1").innerHTML = "otro texto p1";
    document.getElementsByTagName('p').innerHTML = "otro texto p2";
    document.getElementsByClassName("claseP")[0].innerHTML = "otro texto p3";
    var div = document.getElementById("divParrafos");
    div.getElementsByTagName('p')[3].innerHTML = "otro texto p4";
}

function cambioClase(){
    document.getElementById('p2').className = "claseP";
}

function sacoClases(){
    document.getElementById('p3').setAttribute('class','');
}