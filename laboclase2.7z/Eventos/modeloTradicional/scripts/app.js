window.onload = function() {
    this.document.getElementById("titulo").addEventListener("click", saludar, false);
    this.document.getElementById("titulo").addEventListener("click", cambiarColor, false);
}

function saludar()
{
    alert("hola");
    document.getElementById("titulo").removeEventListener("click", saludar);
}

function cambiarColor(cl)
{
    document.getElementById("titulo").style.color = "red";
}