﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.IO;

namespace frmJugador
{
    public partial class frmJugador : Form
    {
        public frmJugador()
        {
            InitializeComponent();
            foreach (EPuesto i in Enum.GetValues(typeof(EPuesto)))
            { this.cboPuesto.Items.Add(i); }
            this.cboPuesto.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cboPuesto.SelectedItem = EPuesto.Arquero;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string texto;
            string path="";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                path = saveFileDialog1.FileNames[0];            
            Jugador jugador = new Jugador(txtNombre.Text, txtApellido.Text, (EPuesto)(cboPuesto.SelectedItem));
            AdministradorDeArchivos.Escribir(path, jugador.ToString(), true);
            AdministradorDeArchivos.Leer(path, out texto);
            MessageBox.Show(texto);
        }

        private void btnTraer_Click(object sender, EventArgs e)
        {
            Jugador jugadorOut;
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\jugadores";
            Jugador jugadorIn = new Jugador(txtNombre.Text, txtApellido.Text, (EPuesto)cboPuesto.SelectedItem);
            txtApellido.Text = "";            
            txtNombre.Text = "";
            cboPuesto.SelectedItem = "";
            MessageBox.Show("buscando");
            if (Jugador.TraerUno(path, jugadorIn, out jugadorOut))
            {
                txtNombre.Text = jugadorOut.Nombre;
                txtApellido.Text = jugadorOut.Apellido;
                cboPuesto.SelectedItem = jugadorOut.Puesto;
                //txtApellido.Enabled = false;
                //txtNombre.Enabled = false;
                //cboPuesto.Enabled = false;
            }
            else { MessageBox.Show("no se encontro"); }         

        }

        
    }
}
