﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum EPuesto { Arquero, Defensa, Medio, Delantero }
    public class Jugador
    {
        protected string _nombre;
        protected string _apellido;        
        protected EPuesto _puesto;
        
        public string Nombre { get{return this._nombre;} }
        public string Apellido { get { return this._apellido; } }
        public EPuesto Puesto { get { return this._puesto; } }

        public Jugador(string nombre, string apellido, EPuesto puesto)
        {
            this._apellido = apellido;
            this._nombre = nombre;
            this._puesto = puesto;
        }
        public override string ToString()
        {
            string cadena = this.Nombre + "-" + this.Apellido + "-" + this.Puesto;
            return cadena;
        }

        public static bool TraerUno(string path, Jugador jIn, out Jugador jOut)
        {
            string jugadores;
            string[] elementos;
            bool retorno= false;
            jOut = null;
            AdministradorDeArchivos.Leer(path, out jugadores);
            foreach(string i in jugadores.Split('\n'))
            {
                elementos = i.Split('-');
                if(jIn._nombre == elementos[0] && jIn._apellido == elementos[1] && jIn._puesto.ToString() == elementos[2].Trim())
                {
                    jOut = new Jugador(elementos[0], elementos[1], (EPuesto)Enum.Parse(typeof(EPuesto), elementos[2]));
                    retorno = true;
                }
            }
            return retorno;    
        }

    }
}
