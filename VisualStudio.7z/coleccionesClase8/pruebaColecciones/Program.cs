﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coleccionesClase8
{
    class Program
    {
        static void Main(string[] args)
        {

            Equipo miEquipo = new Equipo(3, "equipo");
            Jugador j1 = new Jugador("juan", 40059743, 6, 3);
            Jugador j2 = new Jugador("pedro", 40059683, 3, 2);
            Jugador j3 = new Jugador("jorge", 38569426, 6,2);
            

            bool error = miEquipo + j1;
            error = miEquipo + j2;
            error = miEquipo + j3;

            List<Jugador> jugadores = miEquipo.GetJugadores();

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine(jugadores[i].MostrarDatos());
                Console.ReadLine();
            }



                       


            
        }
    }
}
