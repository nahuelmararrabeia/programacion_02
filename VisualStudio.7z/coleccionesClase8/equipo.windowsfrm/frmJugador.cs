﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using coleccionesClase8;

namespace equipo.windowsfrm
{

    public partial class frmJugador : Form
    {
        public frmJugador()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Jugador j1 = new Jugador(this.txtNombre.Text, long.Parse(this.txtDni.Text), float.Parse(this.txtPartidosJugados.Text), float.Parse(this.txtGoles.Text));
            MessageBox.Show(j1.MostrarDatos());           

        }
    }
}
