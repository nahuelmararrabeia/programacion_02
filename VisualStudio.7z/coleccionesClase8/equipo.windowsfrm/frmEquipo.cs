﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using coleccionesClase8;

namespace equipo.windowsfrm
{
        
    public partial class frmEquipo : Form
    {
        Equipo _equipo;
        
        public frmEquipo()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            _equipo = new Equipo(short.Parse(this.txtCantJugadores.Text), this.txtNombre.Text);
            this.txtNombre.Enabled= false;
            this.txtCantJugadores.Enabled=false;
            this.btnAceptar.Visible=false;
            this.btnCancelar.Visible= false;
            //this.lstMostrar = _equipo.GetJugadores();
        }
    }
}
