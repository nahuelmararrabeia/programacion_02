﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coleccionesClase8
{
    public class Equipo
    {
        private short cantidadDeJugarores;
        private List<Jugador> jugadores;
        private string nombre;

        private Equipo()
        {
            jugadores = new List<Jugador>();
            cantidadDeJugarores = 5;
        }

        public Equipo(short cant, string name):this()
        {
            this.cantidadDeJugarores = cant;
            this.nombre = name;
        }

        public static bool operator +(Equipo e, Jugador j)
        {
            bool retorno = false;
            int flag= 0;
            int cant = e.jugadores.Count;
            for (int i = 0; i < cant; i++)
            {
                if (e.jugadores[i] == j)
                {
                    flag = 1;
                }
            }
            if (flag == 0)
            {
                if (cant < e.cantidadDeJugarores)
                {
                    e.jugadores.Add(j);
                    retorno = true;
                }                
            }
            return retorno;
        }

        public List<Jugador> GetJugadores()
        {
            return this.jugadores;
        }
    }
}
