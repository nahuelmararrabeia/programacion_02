﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    class Rectangulo
    {
        private int x;
        private int y;
        private float area;
        private float perimetro;
        private Punto vertice1;
        private Punto vertice2;
        private Punto vertice3;
        private Punto vertice4;

        public float Area();
        public float Perimetro();
        public Rectangulo(Punto v1, Punto v3)
        {
            int v1x;
            int v1y;


           

        }

        

    }
}
