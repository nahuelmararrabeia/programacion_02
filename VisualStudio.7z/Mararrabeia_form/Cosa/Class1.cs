﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioSobrecarga
{
    public class Cosa
    {
        public int entero;
        public string cadena;
        public DateTime fecha;


        public Cosa()
        {
            this.entero = 10;
            this.cadena = "Sin valor";
            this.fecha = DateTime.Now;
        }

        public Cosa(int a, string b, DateTime c)
        {
            this.entero = a;
            this.cadena = b;
            this.fecha = c;
        }

        public Cosa(int a, string b):this(a)
        {
            this.entero = a;
            this.cadena = b;            
        }

        public Cosa(int a):this()
        {
            this.entero = a; 
        }

        /// <summary>
        /// Establecer un valor para un atributo de la clase
        /// </summary>
        /// <param name="a"></param> parametro que inicializara el atributo entero de nuestra clase
        public void EstablecerValor(int a)
        {
            this.entero = a;
        }

        /// <summary>
        /// Establecer un valor para un atributo de la clase
        /// </summary>
        /// <param name="a"></param> parametro que inicializara el atributo cadena de nuestra clase
        public void EstablecerValor(string a)
        {
            this.cadena = a;
        }

        /// <summary>
        /// Establecer un valor para un atributo de la clase
        /// </summary>
        /// <param name="a"></param> parametro que inicializara el atributo fecha de nuestra clase
        public void EstablecerValor(DateTime a)
        {
            this.fecha = a;
        }

        /// <summary>
        /// Devuelve un string con entero, cadena y fecha, separados por \n
        /// </summary>
        /// <returns></returns>
        public string Mostrar()
        {            
            string cadenaCompleta;

            cadenaCompleta= this.entero + "\n" + this.cadena + "\n" + this.fecha;

            return cadenaCompleta;                        
        }
              


    }
}
