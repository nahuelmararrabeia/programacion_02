window.addEventListener("load", inicializarEventos);

function inicializarEventos(){
    document.getElementById("btnCrear").addEventListener("click", crearObjeto);
}

function crearObjeto(){
    var cadena = '{"nombre":"juan","edad":"24"}';    
    var persona = JSON.parse(cadena);
    document.getElementById("info").innerHTML = persona.nombre;
    document.getElementById("info").innerHTML += " ";
    document.getElementById("info").innerHTML += persona.edad;
}