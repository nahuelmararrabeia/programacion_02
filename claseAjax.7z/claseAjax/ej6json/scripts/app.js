window.addEventListener("load", inicializarEventos);

function inicializarEventos(){
    document.getElementById("btnCargar").addEventListener("click", cargarPersona);
}

function cargarPersona(){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200)
        {
            var autos = JSON.parse(this.responseText);
            var tabla = crearTabla(autos);            
            document.getElementById("info").innerHTML = tabla;
        }
    }    
    xhr.open("GET", "pagina1.php",true);
    xhr.send();
}

function leerDatos(){
    var cadena = "";
    var nombre = document.getElementById("txtNombre").value;
    var edad = document.getElementById("txtEdad").value;
    cadena += "?nombre="+nombre+"&edad="+edad;
    return cadena;
}

function crearTabla(obj){
    var cadena = "<table style='text-align:center'><tr><th>Id</th><th>Marca</th><th>Modelo</th><th>Anio</th></tr>";
    obj.forEach(auto => {
        cadena += "<tr><td>"+auto.id+"</td><td>"+auto.marca+"</td><td>"+auto.modelo+"</td><td>"+auto.anio+"</td></tr>";        
    });
    cadena += "</table>";
    return cadena;
}