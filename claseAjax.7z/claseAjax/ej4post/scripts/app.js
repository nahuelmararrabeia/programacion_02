window.addEventListener("load", inicializarEventos);

function inicializarEventos(){
    document.getElementById("frmPersona").addEventListener("submit", manejarSubmit);
}

function manejarSubmit(e){
    e.preventDefault();
    cargarPersona();
}
function cargarPersona(){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        document.getElementById("info").innerHTML = "<img src='./img/preloader.gif'>";
        if(this.readyState == 4 )
        {
            if(this.status == 200)
            {
                document.getElementById("info").innerHTML = this.responseText;
            }
            else{
                document.getElementById("info").innerHTML = "error:" + this.status + " "+ this.statusText;
            }            
        }
    }
    var data = leerDatos();
    xhr.open("POST", "pagina1.php", true);
    xhr.setRequestHeader("content-Type","application/x-www-form-urlencoded");
    xhr.send(data); 
}

function leerDatos(){
    var cadena = "";
    var nombre = document.getElementById("txtNombre").value;
    var edad = document.getElementById("txtEdad").value;
    cadena += "nombre="+encodeURIComponent(nombre) +"&edad="+encodeURIComponent(edad);
    return cadena;
}